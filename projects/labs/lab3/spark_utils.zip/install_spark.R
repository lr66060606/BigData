# ============================================================
# Setup: Sparklyr 4.0.1 (Hadoop 3) using UK mirror
# ============================================================

# 1. Load sparklyr
if (!requireNamespace("sparklyr", quietly = TRUE)) install.packages("sparklyr")
library(sparklyr)

# 2. Clean up any conflicting Spark installs (manual cleanup)
spark_dir <- path.expand("~\\AppData\\Local\\spark")
if (dir.exists(spark_dir)) {
  message("🧹 Removing old Spark installs from: ", spark_dir)
  unlink(spark_dir, recursive = TRUE, force = TRUE)
} else {
  message("No old Spark installs found.")
}

# 3. Download Spark 4.0.1 (Hadoop 3) from UK mirror
options(timeout = 1800)  # allow longer downloads
url <- "https://www.mirrorservice.org/sites/ftp.apache.org/spark/spark-4.0.1/spark-4.0.1-bin-hadoop3.tgz"
dest <- file.path(tempdir(), "spark-4.0.1-bin-hadoop3.tgz")

message("Downloading Spark 4.0.1 (Hadoop 3) from UK mirror...")
download.file(url, destfile = dest, mode = "wb", method = "libcurl")
message("Download complete: ", dest)

# 4. Install Spark locally (sparklyr will unpack to AppData/Local/spark)
message("Installing Spark via sparklyr...")
sparklyr::spark_install_tar(dest)

# 5. Verify Spark binary path (updated for current sparklyr)
spark_home <- sparklyr::spark_home_dir()

message("Spark home directory: ", spark_home)

# Confirm spark-submit exists
spark_submit_path <- file.path(spark_home, "bin", "spark-submit")
if (file.exists(spark_submit_path)) {
  message("spark-submit found at: ", spark_submit_path)
} else {
  stop("Spark-submit not found — check your Spark installation folder.")
}


# 6. Verify Java installation
message("\nJava check:")
print(Sys.getenv("JAVA_HOME"))
system("java -version")

if (!file.exists(file.path(Sys.getenv("JAVA_HOME"), "bin", "java.exe"))) {
  stop("JAVA_HOME does not point to a valid Java installation.")
}

# 7. Configure Spark connection
cfg <- spark_config()
cfg$sparklyr.arrow <- TRUE
cfg$sparklyr.connect.enableHive <- FALSE

message("\nConnecting to Spark...")
sc <- spark_connect(master = "local[*]", config = cfg, version = "4.0.1")

message("\nSpark connected successfully!\n")
print(spark_version(sc))
