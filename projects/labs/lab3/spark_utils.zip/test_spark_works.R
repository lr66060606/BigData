# ============================================================
# Extended Spark Functional Test — RStudio + sparklyr
# Includes read/write I/O test (CSV)
# ============================================================

library(sparklyr)
library(dplyr)
library(ggplot2)

message("------------------------------------------------------------")
message("TESTING SPARK CONNECTION, COMPUTATION, AND I/O")
message("------------------------------------------------------------")

# --- 1. Configure Spark connection ---
cfg <- spark_config()
cfg$sparklyr.arrow <- TRUE
cfg$sparklyr.connect.enableHive <- FALSE

# Disable Hadoop native I/O (Windows-only workaround)
cfg$sparklyr.shell.conf <- list(
  "spark.hadoop.hadoop.native.io.nativeio.enabled" = "false"
)

# --- 2. Connect to Spark locally ---
message("Connecting to Spark 4.0.1 (local mode)...")
sc <- spark_connect(master = "local[*]", version = "4.0.1", config = cfg)
message("Connection established successfully.\n")



# --- 3. Check connection info ---
info <- spark_connection(sc)
ver <- spark_version(sc)
cat("Spark version:", ver$spark, "\n")
cat("Hadoop version:", ver$hadoop, "\n")
cat("Spark home:", info$spark_home, "\n")
cat("Master:", info$master, "\n\n")

# --- 4. Upload sample dataset to Spark ---
message("Copying iris dataset to Spark...")
iris_tbl <- copy_to(sc, iris, overwrite = TRUE)

# --- 5. Run a distributed computation ---
message("Running distributed computation...")
summary_tbl <- iris_tbl %>%
  group_by(Species) %>%
  summarise(
    avg_sepal_length = mean(Sepal_Length),
    avg_sepal_width  = mean(Sepal_Width),
    avg_petal_length = mean(Petal_Length),
    avg_petal_width  = mean(Petal_Width)
  ) %>%
  arrange(Species) %>%
  collect()

message("Computation complete.\n")
print(summary_tbl)

# --- 6. Plot result in R (not Spark) ---
message("Plotting summary results...")
ggplot(summary_tbl, aes(x = Species, y = avg_sepal_length, fill = Species)) +
  geom_col() +
  labs(
    title = "Average Sepal Length by Species (computed in Spark)",
    x = "Species", y = "Average Sepal Length"
  ) +
  theme_minimal()


# --- 7. Disconnect ---
message("\nDisconnecting from Spark...")
spark_disconnect(sc)
message("Spark session closed successfully.")

message("------------------------------------------------------------")
message("Spark functional + I/O test completed successfully.")
message("------------------------------------------------------------")
