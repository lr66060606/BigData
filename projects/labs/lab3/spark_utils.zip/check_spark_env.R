# ============================================================
# Spark Diagnostic Script — RStudio + Java + sparklyr
# ============================================================

library(sparklyr)
library(dplyr)

message("------------------------------------------------------------")
message("SPARKLYR ENVIRONMENT CHECK")
message("------------------------------------------------------------")

# --- 1. Check Java installation ---
message("\nChecking JAVA_HOME...")
java_home <- Sys.getenv("JAVA_HOME")
if (java_home == "") stop("JAVA_HOME not set.")
message("JAVA_HOME = ", java_home)

java_ok <- file.exists(file.path(java_home, "bin", "java.exe"))
if (!java_ok) stop("java.exe not found at: ", file.path(java_home, "bin"))
message("Java found at: ", file.path(java_home, "bin", "java.exe"))

message("\nJava version:")
system2(file.path(java_home, "bin", "java.exe"), "-version")

# --- 2. Check Spark installation ---
message("\nChecking Spark installation...")
spark_home <- Sys.getenv("SPARK_HOME")

if (spark_home == "") {
  spark_home <- sparklyr::spark_home_dir()
  message("SPARK_HOME not set; using detected directory: ", spark_home)
} else {
  message("SPARK_HOME = ", spark_home)
}

spark_submit <- file.path(spark_home, "bin", "spark-submit")
if (!file.exists(spark_submit)) stop("spark-submit not found at: ", spark_submit)
message("spark-submit found.")

# Test spark-submit command
message("\nRunning spark-submit --version ...")
system2(spark_submit, "--version")

# --- 3. Test Spark connection via sparklyr ---
message("\nAttempting sparklyr connection...")
cfg <- spark_config()
cfg$sparklyr.arrow <- TRUE
cfg$sparklyr.connect.enableHive <- FALSE

sc <- tryCatch(
  spark_connect(master = "local[*]", config = cfg, version = "4.0.1"),
  error = function(e) {
    message("spark_connect() failed: ", e$message)
    stop("Spark connection unsuccessful.")
  }
)
message("spark_connect() succeeded.")
message("Connected to Spark version: ", spark_version(sc))

# --- 4. Simple data test ---
message("\nTesting data transfer and aggregation...")
df <- copy_to(sc, iris, overwrite = TRUE)
result <- df %>%
  group_by(Species) %>%
  summarise(avg_sepal = mean(Sepal_Length)) %>%
  collect()

print(result)

# --- 5. Disconnect ---
spark_disconnect(sc)
message("\nSpark diagnostic completed successfully!")

message("------------------------------------------------------------")
message("All checks passed! Spark and Java are correctly configured.")
message("------------------------------------------------------------")
