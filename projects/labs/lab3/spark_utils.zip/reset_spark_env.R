# ============================================================
# Spark Environment Reset Script — RStudio + Java + sparklyr
# ============================================================
# a safe cleanup and reinstall utility for sparklyr on Windows.
# It’s meant to repair broken Spark installations 
# (like an empty hadoop2.7 folder) and re-establish a 
# working environment.
# Everything happens inside your Windows user profile (AppData\Local\spark).

library(sparklyr)

message("------------------------------------------------------------")
message("RESETTING SPARK ENVIRONMENT")
message("------------------------------------------------------------")

# --- 1. Define target Spark version and UK mirror URL ---
spark_version <- "4.0.1"
hadoop_version <- "3"
spark_url <- paste0(
  "https://www.mirrorservice.org/sites/ftp.apache.org/spark/spark-",
  spark_version, "/spark-", spark_version, "-bin-hadoop", hadoop_version, ".tgz"
)

# --- 2. Remove all cached Spark installs ---
spark_dir <- path.expand("~\\AppData\\Local\\spark")
if (dir.exists(spark_dir)) {
  message("Removing old Spark installations from: ", spark_dir)
  unlink(spark_dir, recursive = TRUE, force = TRUE)
} else {
  message("No previous Spark installations found.")
}

# --- 3. Download Spark from UK mirror ---
options(timeout = 1800)
dest <- file.path(tempdir(), paste0("spark-", spark_version, "-bin-hadoop", hadoop_version, ".tgz"))
message("Downloading Spark ", spark_version, " (Hadoop ", hadoop_version, ") from UK mirror...")
download.file(spark_url, destfile = dest, mode = "wb", method = "libcurl")
message("Download complete: ", dest)

# --- 4. Install Spark locally ---
message("Installing Spark via sparklyr...")
sparklyr::spark_install_tar(dest)

# --- 5. Identify installed Spark home ---
installed <- sparklyr::spark_installed_versions()
spark_home <- installed$dir[installed$spark == spark_version & installed$hadoop == hadoop_version][1]

if (is.na(spark_home) || !dir.exists(spark_home)) {
  stop("Spark installation failed: could not find installed directory.")
}

message("Spark installed successfully at: ", spark_home)

# --- 6. Set SPARK_HOME environment variable ---
Sys.setenv(SPARK_HOME = spark_home)
message("SPARK_HOME set to: ", Sys.getenv("SPARK_HOME"))

# --- 7. Verify spark-submit(.cmd) exists and works ---
bin_dir <- file.path(Sys.getenv("SPARK_HOME"), "bin")

# Prefer .cmd on Windows, fallback to Unix script if needed
spark_submit_cmd <- if (file.exists(file.path(bin_dir, "spark-submit.cmd"))) {
  file.path(bin_dir, "spark-submit.cmd")
} else {
  file.path(bin_dir, "spark-submit")
}

if (!file.exists(spark_submit_cmd)) {
  stop("spark-submit not found in expected directory: ", bin_dir)
} else {
  message("spark-submit located at: ", spark_submit_cmd)
}

# Test that Spark launches successfully
message("\nTesting spark-submit command:")
tryCatch({
  system2(spark_submit_cmd, "--version")
  message("\nSpark submit executed successfully.")
}, error = function(e) {
  message("Error while testing spark-submit: ", e$message)
  stop("Spark command-line test failed. Check Java configuration or extraction.")
})

# --- 8. Display installed versions ---
message("\nInstalled Spark versions:")
print(sparklyr::spark_installed_versions())

message("------------------------------------------------------------")
message("Spark environment reset and verification completed successfully.")
message("You can now run check_spark_env.R to test sparklyr connectivity.")
message("------------------------------------------------------------")